import React from 'react'
import Weather from './components/Weather'

export default function App() {
  return (
    <div>
      <Weather />
    </div>
  )
}
